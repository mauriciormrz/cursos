1. Install Java SE Development Kit 7 on your PC:
http://www.oracle.com/technetwork/java/javase/downloads/index.html

2. Edit "one.txt" file inside parser's folder:
paste hex packet here and save.

3. Run Fm decoder.bat  and you will see parsed info inside console window.
